from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
from re import search
from os import listdir
import random

profile_dic = 'C://Users//Raq//Desktop//Others//hakan_picinin_isi//spam_bot2//used_profiles'

line = ["Hey guys{}".format("." * random.randint(0,7)), "Did you hear about Supreme Investements?", 
		"I suggest you guys to join them {}".format(":) " * random.randint(0,4)), 
		"They are great and I heard they are PND again{}".format("." * random.randint(0,7))]

class Spammer():
	acc = ''
	count = 0
	profile_num = 0
	profile = webdriver.FirefoxProfile(profile_dic + '//%s//' % listdir(profile_dic)[random.randint(0, len(listdir(profile_dic)))])
	driver = webdriver.Firefox(profile)
	spam_txt = open('spam.txt', 'r').read().split()
	insta_ban = open('spam.txt', 'r').read().split("#")[0].split("\n")

	def prof_change(num):
		try:
			Spammer.acc = '%s//%s//' % (profile_dic, Spammer.listdir(profile_dic)[num])
		except IndexError:
			Spammer.profile_num, num = 0, 0
			Spammer.acc = '%s//%s//' % (profile_dic, Spammer.listdir(profile_dic)[num])

		Spammer.profile = webdriver.FirefoxProfile(Spammer.acc)
		Spammer.driver = webdriver.Firefox(Spammer.profile)
		return Spammer.event()

	def join():
		Spammer.driver.get("https://web.telegram.org/#/im")
		sleep(15)
		area_tel = Spammer.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[2]/form/div[2]/div[1]/input")
		area_tel.send_keys(Keys.CONTROL,"a")
		area_tel.send_keys("+1")
		phone = Spammer.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[2]/form/div[2]/div[2]/input")
		phone.send_keys("7209906742")
		sleep(1)
		Spammer.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[1]/div/a/my-i18n").click()
		sleep(2)
		Spammer.driver.find_element_by_xpath("/html/body/div[4]/div[2]/div/div/div[2]/button[2]").click()
		input("ready?")
		return Spammer.event()

	def look_for_error(channel_number, **kwargs):
		sleep(10)
		for error_might_be in Spammer.driver.find_elements_by_xpath("//h4[@class]"):
			try:
				if error_might_be.get_attribute("class") == "md_simple_header":
					Spammer.driver.find_element_by_xpath("//a[@class='error_modal_details_link']").click()
					sleep(2)
					whole_message = Spammer.driver.find_element_by_xpath("/html/body/div[5]/div[2]/div/div/div[1]/div[2]/textarea").text
					error_message = search('"error_message":"', whole_message)
					wait_time = whole_message[error_message.end():].split("_")[-1].split('"')[0]
					# print(whole_message, wait_time, sep=" ,", flush=True)
					print(wait_time)
					if wait_time == "FORBIDDEN" or wait_time == "PRIVATE":
						pass
					elif wait_time == "CHANNEL":
						Spammer.profile_num += 1
						return Spammer.prof_change(Spammer.profile_num)
					try:
						print("Waiting {} mins".format(round(int(wait_time) / 60)))
						sleep(int(wait_time) + 5)
					except:
						Spammer.driver.get("https://web.telegram.org/#/im?p=@{}".format(Spammer.spam_txt[channel_number + random.randint(1, 5)]))
				else:
					pass
			except:
				pass

	def write(channel_number):
		write_bar = Spammer.driver.find_element_by_xpath("/html/body/div[1]/div[2]/div/div[2]/div[3]/div/div[3]/div[2]/div/div/div/form/div[2]/div[5]")
		for i in range(len(line)):
			write_bar.send_keys(line[i])
			write_bar.send_keys(Keys.SHIFT, Keys.ENTER)
			sleep(0.1)
			
		if channel_number < len(Spammer.insta_ban):
			write_bar.send_keys('to join (at) supreme_investments')
		else:
			write_bar.send_keys('@supreme_investments')
		sleep(0.1)
		write_bar.send_keys(Keys.ENTER)

	def try_join():
		for join_might_be in Spammer.driver.find_elements_by_xpath("//a[@ng-click]"):
			if join_might_be.get_attribute("ng-click") == "joinChannel()":
				Spammer.driver.find_element_by_xpath("//a[@ng-click='joinChannel()']").click()
	def event():
		for channel_number in range(len(Spammer.spam_txt)):
			Spammer.driver.get("https://web.telegram.org/#/im?p=@{}".format(Spammer.spam_txt[channel_number]))

			#LOOKING FOR ERROR#
			Spammer.look_for_error(channel_number)

			Spammer.try_join()

			#LOOKING FOR ERROR#
			Spammer.look_for_error(channel_number)

			try:
				Spammer.write(channel_number)
			except:
				print("excepted")
				pass

			#LOOKING FOR ERROR#
			Spammer.look_for_error(channel_number)

			if Spammer.count > len(Spammer.spam_txt):
				# NOT SURE IF NECCESARY OR NOT
				# channel_number = 0
				sleep(50)
			else:
				sleep(100)

			Spammer.count += 1
			print(Spammer.count)

		return Spammer.event()

while True:
	Spammer.event()