from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
from re import search
from random import randint

class Spammer():
	count = 0
	profile = webdriver.FirefoxProfile('//home//mirkan//.mozilla//firefox//w8z62y4j.default//')
	driver = webdriver.Firefox(profile)
	spam_txt = open('spam.txt', 'r').read().split()

	def join():
		Spammer.driver.get("https://web.telegram.org/#/im")
		sleep(20)
		area_tel = Spammer.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[2]/form/div[2]/div[1]/input")
		area_tel.send_keys(Keys.CONTROL,"a")
		area_tel.send_keys("+1")
		# sleep(5)
		# p_number = int(input("Give me the number: "))
		phone = Spammer.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[2]/form/div[2]/div[2]/input")
		phone.send_keys("7209906742")
		sleep(1)
		Spammer.driver.find_element_by_xpath("/html/body/div[1]/div/div[2]/div[1]/div/a/my-i18n").click()
		sleep(2)
		Spammer.driver.find_element_by_xpath("/html/body/div[4]/div[2]/div/div/div[2]/button[2]").click()
		input("ready?")
		return Spammer.event()

	def look_for_error(channel_number):
		sleep(20)
		# print("look_for_error - ", channel_number + 1)
		for error_might_be in Spammer.driver.find_elements_by_xpath("//h4[@class]"):
			try:
				if error_might_be.get_attribute("class") == "md_simple_header":
					print("Error Found")
					Spammer.driver.find_element_by_xpath("//a[@class='error_modal_details_link']").click()
					sleep(2)
					whole_message = Spammer.driver.find_element_by_xpath("/html/body/div[5]/div[2]/div/div/div[1]/div[2]/textarea").text
					error_message = search('"error_message":"', whole_message)
					wait_time = whole_message[error_message.end():].split("_")[-1].split('"')[0]
					#print(whole_message)
					#print(error_message)
					print(wait_time)
					try:
						print("Waiting {} mins".format(round(int(wait_time) / 60)))
						sleep(int(wait_time) + 5)
					except:
						Spammer.driver.get("https://web.telegram.org/#/im?p=@{}".format(Spammer.spam_txt[channel_number + randint(1, 5)]))
				else:
					pass
			except:
				pass

	def write(channel_number):
		write_bar = Spammer.driver.find_element_by_xpath("/html/body/div[1]/div[2]/div/div[2]/div[3]/div/div[3]/div[2]/div/div/div/form/div[2]/div[5]")
		write_bar.send_keys('Supreme Investments')
		write_bar.send_keys(Keys.SHIFT, Keys.ENTER)
		sleep(0.1)
		write_bar.send_keys('We are an investment channel about crypto currencies.')
		write_bar.send_keys(Keys.SHIFT, Keys.ENTER)
		sleep(0.1)
		# write_bar.send_keys('Our campaign will start when there are 1000 users who are also will be in core group.')
		# write_bar.send_keys(Keys.SHIFT, Keys.ENTER)
		# sleep(0.1)
		# write_bar.send_keys('We are going to share short or long term signals that are backed and discussed by experts with first comers.')
		# write_bar.send_keys(Keys.SHIFT, Keys.ENTER)
		# sleep(0.1)
		write_bar.send_keys('Join us... ')

		if channel_number < 14:
			write_bar.send_keys('search for (at) supreme_investments on telegram')
		else:
			write_bar.send_keys('@supreme_investments')
		sleep(0.1)
		write_bar.send_keys(Keys.ENTER)

	def event():
		for channel_number in range(len(Spammer.spam_txt)):
			Spammer.driver.get("https://web.telegram.org/#/im?p=@{}".format(Spammer.spam_txt[channel_number]))

			#LOOKING FOR ERROR#
			Spammer.look_for_error(channel_number = channel_number)

			for join_might_be in Spammer.driver.find_elements_by_xpath("//a[@ng-click]"):
				if join_might_be.get_attribute("ng-click") == "joinChannel()":
					Spammer.driver.find_element_by_xpath("//a[@ng-click='joinChannel()']").click()
					break
				else:
					pass

			#LOOKING FOR ERROR#
			Spammer.look_for_error(channel_number = channel_number)

			try:
				Spammer.write(channel_number = channel_number)
			except:
				pass

			if Spammer.count > len(Spammer.spam_txt):
				# NOT SURE IF NECCESARY OR NOT
				# channel_number = 0
				sleep(30)
			else:
				sleep(100)

			Spammer.count += 1
			print(Spammer.count)

		return Spammer.event()

try:
	Spammer.event()
except:
	raise
	input("RETRY?")
	Spammer.event()